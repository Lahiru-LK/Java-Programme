public class CarDemo
{
	public static void main(String[] args) {
		

		//Creating a car with color
		Car c = new Car("red");

	}
	
}

//Creating a car with default constructor
//Car c = new Car();

//Creating a car with color and speed
//Car c = new Car("blue", 65);

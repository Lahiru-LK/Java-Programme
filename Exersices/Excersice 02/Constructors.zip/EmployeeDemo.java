public class EmployeeDemo
{
	public static void main(String[] args) {
		//Creating objects with default constructor
		//Employee emp = new Employee();

		//Creating objects with parameterized constructor, name
		//Employee emp2 = new Employee("Nimal");

		//Creating objects with parameterized constructor, all
		Employee emp3 = new Employee("Kamal", 20 , 'M');
	}
	
}
